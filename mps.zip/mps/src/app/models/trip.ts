export interface Trip {
    id: string;
    fromAddress: string;
    fromCity: string;
    fromCountry: string;
    toAddress: string;
    toCity: string;
    toCountry: string;
    date: string;
    price: string;
    freeSeats: number;
    driversName: string;
    driversRating: number;
}