import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../models/user';
import { retry, catchError, filter, map } from 'rxjs/operators';
import { Observable, of as observableOf } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  apiURL = 'http://localhost:3000';

  constructor(private http: HttpClient) {
   }

   httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(this.apiURL + '/users');
  }

  addUser(user : User): Observable<User> {
    return this.http.post<User>(this.apiURL + "/users", user, this.httpOptions);
  }
}
