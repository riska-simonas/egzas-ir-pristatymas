import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Trip } from 'src/app/models/trip';

@Injectable({
  providedIn: 'root'
})
export class TripService {

  apiURL = 'http://localhost:3000';

  constructor(private http: HttpClient) {
   }

   httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.apiURL + '/trips');
  }

  addTrip(trip : Trip): Observable<Trip> {
    return this.http.post<Trip>(this.apiURL + "/trips", trip, this.httpOptions);
  }
}
