import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private authentication : AuthenticationService, private router : Router) { }

  ngOnInit(): void {
  }

  username = "";
  password = "";
  firstname = "";
  lastname = "";

  trips = [
    {id: 1, fromAdress: "Saulėtekio al. 11", fromCity: "Vilnius", fromCountry: "Lietuva", toAdress: "Vilniaus g. 27", toCity: "Vilnius", toCountry: "Lietuva", date: "2022-10-31", price: "2", freeSeats: 3, driversName: "Simon R.", driversRating: 5.00},
    {id: 2, fromAdress: "Justiniškių g. 77", fromCity: "Vilnius", fromCountry: "Lietuva", toAdress: "Jogailos g. 12", toCity: "Vilnius", toCountry: "Lietuva", date: "2022-11-01", price: "2", freeSeats: 3, driversName: "Jonas J.", driversRating: 4.47},
    {id: 3, fromAdress: "Oginskio g. 5", fromCity: "Vilnius", fromCountry: "Lietuva", toAdress: "Pilies g. 27", toCity: "Vilnius", toCountry: "Lietuva", date: "2022-11-01", price: "3", freeSeats: 3, driversName: "Petras P.", driversRating: 4.98}
  ];

  calculateMaxTripPrice(): number {
    let maxTripPrice = 0;
    for (let i = 0; i < this.trips.length; i++) {
      if(parseInt(this.trips[i].price) > maxTripPrice) {
        maxTripPrice = parseInt(this.trips[i].price);
      }
    }
    return maxTripPrice;
  }

  register(): void {
    let id;
    this.authentication.getUsers().subscribe(res => {
      id = res.length.toString();
      let user: {id: string, username: string, password: string, firstname: string, lastname: string} = {id: id, username: this.username, password: this.password, firstname: this.firstname, lastname: this.lastname};
      this.authentication.addUser(user).subscribe(() => {
        this.router.navigateByUrl('/login');
      });
    });
  }

}
