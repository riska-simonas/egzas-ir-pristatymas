import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from 'src/app/models/user';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor(private router : Router, private authentication : AuthenticationService ) { }


  ngOnInit(): void {
  }

  openSearch(): void {
    this.router.navigateByUrl('search');
  }

  openAddTrip(): void {
    this.router.navigateByUrl('add');
  }

}
