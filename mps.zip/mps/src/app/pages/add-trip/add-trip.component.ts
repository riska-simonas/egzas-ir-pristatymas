import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TripService } from 'src/app/services/trips/trip.service';

@Component({
  selector: 'app-add-trip',
  templateUrl: './add-trip.component.html',
  styleUrls: ['./add-trip.component.css']
})
export class AddTripComponent implements OnInit {

  constructor(private tripService : TripService, private router : Router) { }

  ngOnInit(): void {
  }

  addressFrom = "";
  addressTo = "";
  date = "";
  price = "";
  freeSeats = 1;


  addTrip(): void {
    let id;
    let fromAddress = this.addressFrom.split(",")[0].trim();
    let fromCity = this.addressFrom.split(",")[1].trim();
    let fromCountry = this.addressFrom.split(",")[2].trim();
    let toAddress = this.addressTo.split(",")[0].trim();
    let toCity = this.addressTo.split(",")[1].trim();
    let toCountry = this.addressTo.split(",")[2].trim();
    console.log(fromAddress + " 123 " + fromCity + " 123 " + fromCountry);
    this.tripService.getTrips().subscribe(res => {
      id = res.length.toString();
      let trip: {id: string, fromAddress: string, fromCity: string, fromCountry: string, toAddress: string, toCity: string, toCountry: string, date: string, price: string, freeSeats: number, driversName: string, driversRating: number} = {id: id, fromAddress: fromAddress, fromCity: fromCity, fromCountry: fromCountry, toAddress: toAddress, toCity: toCity, toCountry: toCountry, date: this.date, price: this.price, freeSeats: this.freeSeats, driversName: "John D.", driversRating: 5.00};
      this.tripService.addTrip(trip).subscribe(() => {
        this.router.navigateByUrl('/search');
      });
    });
  }

}
