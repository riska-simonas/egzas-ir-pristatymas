import { Component, OnInit } from '@angular/core';
import { Trip } from 'src/app/models/trip';
import { TripService } from 'src/app/services/trips/trip.service';

@Component({
  selector: 'app-trip-search',
  templateUrl: './trip-search.component.html',
  styleUrls: ['./trip-search.component.css']
})
export class TripSearchComponent implements OnInit {

  userLoggedIn : boolean = false;

  constructor(private tripService : TripService) { }

  ngOnInit(): void {
    this.userLoggedIn = sessionStorage.getItem("loggedIn")=="true"? true : false;
    this.getAllTrips();
  }

  searchAddressTo: string = "";
  searchAddressFrom: string = "";
  searchDate: Date | undefined;
  searchPrice: number | undefined;

  trips: Trip[] = [];

  findMaxPriceOfTrip(): number {
    let maxTripPrice = 0;
    for (let trip of this.trips) {
      if (parseInt(trip.price) > maxTripPrice) {
        maxTripPrice = parseInt(trip.price);
      }
    }
    return maxTripPrice;
  }

  getAllTrips() {
    this.tripService.getTrips().subscribe((res) =>
    {
      res.forEach(trip => this.trips.push(trip));
    });
  }

}
