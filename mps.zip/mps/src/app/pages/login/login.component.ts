import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private authentication : AuthenticationService, private router : Router) { }

  ngOnInit(): void {
  }

  username= "";
  password="";

  logIn() {
    let username = this.username;
    let password = this.password;
    this.authentication.getUsers().subscribe(res => {
      if(res.filter(user => user.username == username && user.password == password).length > 0) {
        console.log("Logged in successfully");
        sessionStorage.setItem("loggedIn", "true"); 
        this.router.navigate(['']).then(() => {
          location.reload();
        });
      } else {
        console.log("No such account");
      }
    });
  }


}
