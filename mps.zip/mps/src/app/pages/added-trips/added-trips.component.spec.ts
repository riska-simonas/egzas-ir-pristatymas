import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddedTripsComponent } from './added-trips.component';

describe('AddedTripsComponent', () => {
  let component: AddedTripsComponent;
  let fixture: ComponentFixture<AddedTripsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddedTripsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddedTripsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
