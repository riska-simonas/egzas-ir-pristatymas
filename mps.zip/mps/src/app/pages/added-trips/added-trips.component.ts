import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-added-trips',
  templateUrl: './added-trips.component.html',
  styleUrls: ['./added-trips.component.css']
})
export class AddedTripsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  searchAddressTo: string = "";
  searchAddressFrom: string = "";
  searchDate: Date | undefined;
  searchPrice: number | undefined;

  trips: { id: number, fromAddress: string, fromCity: string, fromCountry: string, toAddress: string, toCity: string, toCountry: string, date: string, price: string, freeSeats: number, driversName: string, driversRating: number}[] = [
    {id: 1, fromAddress: "Taikos g. 5", fromCity: "Vilnius", fromCountry: "Lietuva", toAddress: "Bitininkų g. 3", toCity: "Vilnius", toCountry: "Lietuva", date: "2022-12-14", price: "2", freeSeats: 3, driversName: "John D.", driversRating: 5.00}
  ];

  findMaxPriceOfTrip(): number {
    let maxTripPrice = 0;
    for (let trip of this.trips) {
      if (parseInt(trip.price) > maxTripPrice) {
        maxTripPrice = parseInt(trip.price);
      }
    }
    return maxTripPrice;
  }

  deleteTrip(id: number) {
    this.trips = this.trips.filter(trip => trip.id !== id);
  }

}
