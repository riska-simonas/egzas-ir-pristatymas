import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  userLoggedIn : boolean = false;

  constructor(private router : Router) { }

  ngOnInit(): void {
    this.userLoggedIn = sessionStorage.getItem("loggedIn")=="true"? true : false;
  }

  openHomepage() {
    this.router.navigateByUrl('');
  }

  openSearch() {
    this.router.navigateByUrl('search');
  }

  openAddTrip() {
    if (this.userLoggedIn) {
      this.router.navigateByUrl('add');
    } else {
      this.router.navigateByUrl('login');
    }
  }

  openLogin() {
    this.router.navigateByUrl('login');
  }

  openRegister() {
    this.router.navigateByUrl('register');
  }

  openReservedTrips() {
    this.router.navigateByUrl('reserved-trips');
  }

  openAddedTrips() {
    this.router.navigateByUrl('added-trips');
  }

  logOff() {
    this.userLoggedIn = false;
    sessionStorage.setItem("loggedIn", "false");
    location.reload();
  }

}
